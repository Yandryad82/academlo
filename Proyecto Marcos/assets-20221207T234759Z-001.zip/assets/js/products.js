const itemsP = [
    {
      id: 1,
      name: 'Hoodies',
      price: 14.00,
      image: 'assets/images/featured1.png',
      category: 'hoodies',
      quantity: 10,
      type: "vinil",
      classification: "glitter",
      qs: 0
    },
    {
      id: 2,
      name: 'Shirts',
      price: 24.00,
      image: 'assets/images/featured2.png',
      category: 'shirts',
      quantity: 15,
      type: "cinta",
      classification: "llana",
      qs: 0
    },
    {
      id: 3,
      name: 'Sweatshirts',
      price: 24.00,
      image: 'assets/images/featured3.png',
      category: 'sweatshirts',
      quantity: 20,
      type: "aplique",
      classification: "coronitas",
      qs: 0
    },
    {
      id: 4,
      name: 'Sweatshirts',
      price: 24.00,
      image: 'assets/images/featured3.png',
      category: 'sweatshirts',
      quantity: 20,
      type: "decorable",
      classification: "vinchas",
      qs: 0
    }
  ]